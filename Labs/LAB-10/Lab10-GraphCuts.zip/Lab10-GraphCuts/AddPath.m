addpath(genpath([pwd '/Cuts']));
addpath(genpath([pwd '/data']));